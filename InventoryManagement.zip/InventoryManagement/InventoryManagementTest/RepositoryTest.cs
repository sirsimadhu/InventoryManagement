using InventoryManagement.Model;
using InventoryManagement.Repository;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InventoryManagementTest
{
    [TestClass]
    public class RepositoryTest
    {
        IRepository repository;

        [TestInitialize]
        public void Initialize()
        {

            repository = new RepositoryImpl();
            repository.ClearData();
            Inventory inventory = new Inventory() { ItemName = "Book01", BuyingPrice = 120.22, SellingPrice = 130.00, Quantity = 10 };
            repository.CreateInventory(inventory);
            inventory = new Inventory() { ItemName = "Food01", BuyingPrice = 121.22, SellingPrice = 135.00, Quantity = 12 };
            repository.CreateInventory(inventory);
            inventory = new Inventory() { ItemName = "Med01", BuyingPrice = 123.22, SellingPrice = 140.00, Quantity = 13 };
            repository.CreateInventory(inventory);
            inventory = new Inventory() { ItemName = "Tab01", BuyingPrice = 130.22, SellingPrice = 140.00, Quantity = 15 };
            repository.CreateInventory(inventory);
        }

        [TestMethod]
        public void TestCreateItem()
        {
            Inventory inventory = new Inventory() { ItemName = "zook05", BuyingPrice = 120.22, SellingPrice = 130.00, Quantity = 10 };
            repository.CreateInventory(inventory);
            Assert.AreEqual(repository.GetAllItems().Count, 5);
            Assert.AreEqual(repository.GetAllItems()[0].ItemName, "Book01");
            Assert.AreEqual(repository.GetAllItems()[0].SellingPrice, 130.00);
            Assert.AreEqual(repository.GetAllItems()[0].Quantity, 10);

            Assert.AreEqual(repository.GetAllItems()[1].ItemName, "Food01");
            Assert.AreEqual(repository.GetAllItems()[1].SellingPrice, 135.00);
            Assert.AreEqual(repository.GetAllItems()[1].Quantity, 12);

        }

        [TestMethod]
        public void TestUpdateItem()
        {
            Inventory invtry = repository.GetItemById(1);
            invtry.ItemName = "Book001";
            repository.UpdateInventory(invtry);

            Assert.AreEqual(repository.GetAllItems().Count, 4);
            Assert.AreEqual(repository.GetAllItems()[0].ItemName, "Book001");
            Assert.AreEqual(repository.GetAllItems()[0].SellingPrice, 130.00);
            Assert.AreEqual(repository.GetAllItems()[0].Quantity, 10);
        }

        [TestMethod]
        public void TestDeleteItem()
        {
            repository.DeleteInventory(1);
         
            Assert.AreEqual(repository.GetAllItems().Count, 3);
            Assert.AreEqual(repository.GetAllItems()[0].ItemName, "Food01");
            Assert.AreEqual(repository.GetAllItems()[0].SellingPrice, 135.00);
            Assert.AreEqual(repository.GetAllItems()[0].Quantity, 12);
        }
    }
}
