﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagement.Model;
using InventoryManagement.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InventoryManagement.Pages.View
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Inventory inventory { get; set; }
        [BindProperty]
        public String PageHeader { get; set; }
        private IRepository itemRepository;
        public CreateModel(IRepository repository)
        {
            itemRepository = repository;
            PageHeader = "Create Item";
        }

        public void OnGet(int id)
        {
            if(id > 0)
            {
                inventory = itemRepository.GetItemById(id);
                PageHeader = "Update Item";
            }
            
        }
        public IActionResult OnPost(string itemName, double bprice, double sprice,int qty)
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
           inventory = new Inventory() { ItemName = itemName, BuyingPrice = bprice, SellingPrice = sprice, Quantity = qty };
           itemRepository.CreateInventory(inventory);
           return RedirectToPage("../Index");
        }
    }
}