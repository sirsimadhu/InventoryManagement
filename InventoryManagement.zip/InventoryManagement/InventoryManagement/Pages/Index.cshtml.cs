﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagement.Model;
using InventoryManagement.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InventoryManagement.Pages
{
    public class IndexModel : PageModel
    {
        private IRepository itemRepository;
        [BindProperty]
        public IList<Inventory> inventories { get; set; }
        [BindProperty]
        public double GrandTotal { get; set; }

        public IndexModel(IRepository _itemRepository)
        {
            itemRepository = _itemRepository;
        }
        public void OnGet()
        {
            inventories = itemRepository.GetAllItems();
            GrandTotal = itemRepository.GrandTotal();
        }
    }
}
