﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
   
    public class Inventory
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Item Name Required!")]
        public string ItemName { get; set; }
        [Required(ErrorMessage ="Buying At Required!")]
        [RegularExpression("^(-?)(0|([1-9][0-9]*))(\\.[0-9]+)?$")]
        public double BuyingPrice { get; set; }
        [Required(ErrorMessage = "Selling At Required!")]
        [RegularExpression("^(-?)(0|([1-9][0-9]*))(\\.[0-9]+)?$")]
        public double SellingPrice { get; set; }
        [Required(ErrorMessage = "Quantity Required!")]
        [RegularExpression("^\\d+$")]
        public int Quantity { get; set; }
        public double TotalValue {
            get
            {
                return Quantity * BuyingPrice;
            }
        }
    }
}
