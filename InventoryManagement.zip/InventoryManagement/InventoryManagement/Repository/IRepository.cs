﻿using InventoryManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InventoryManagement.Repository
{

    //Repository class to persit and retrieve data.
    public interface IRepository
    {
        //Create inventory item
        bool CreateInventory(Inventory item);
        //Update inventory item
        bool UpdateInventory(Inventory item);
        //Delete inventory item
        bool DeleteInventory(int id);
        //Gets all item available in inventory
        IList<Inventory> GetAllItems();
        //Get single item from the repo
        Inventory GetItemById(int id);
        //Gets Grand total
        double GrandTotal();

        void ClearData();
    }
}
