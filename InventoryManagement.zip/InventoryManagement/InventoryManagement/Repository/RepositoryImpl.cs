﻿using System;
using System.Collections.Generic;
using System.Linq;
using InventoryManagement.Model;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace InventoryManagement.Repository
{
  
    public class RepositoryImpl : IRepository
    {
        //Static list to hold all inventory Item
        private static IList<Inventory> itemList = new List<Inventory>();

        //Clears all item from repo
        public void ClearData()
        {
            if (itemList.Count > 0)
            {
                itemList.Clear();
            }
           
        }

        //Method create inventory item
        public bool CreateInventory(Inventory item)
        {
            try
            {
                item.Id = itemList.Count == 0 ? 1 : itemList.Count + 1;
                itemList.Add(item);
                return itemList.Count > 0;
            }
            catch (Exception ex)
            {
                //Implement logger here
                throw new Exception("Create Command failed to add item." + ex.Message);
            }
        }

        //Method deletes inventory item
        public bool DeleteInventory(int id)
        {
            try
            {
                Inventory item = itemList.SingleOrDefault(p => p.Id == 1);
                if (item != null)
                {
                    return itemList.Remove(item);
                }
                return false;
            }
            catch (Exception ex)
            {
                //Implement logger here
                throw new Exception("Delete Command failed to delete item." + ex.Message);
            }
        }

        //Gets all inventory item
        public IList<Inventory> GetAllItems()
        {
            if (itemList.Count > 0)
            {
                itemList = itemList.ToArray().OrderBy(t => t.ItemName).ToList();
            }
            return itemList;
        }

        //Gets single item from repo
        public Inventory GetItemById(int id)
        {
            try
            {
                return itemList.SingleOrDefault(p => p.Id == 1);
            }
            catch (Exception ex)
            {
                //Implement logger here
                throw new Exception("Get Item Command failed get item." + ex.Message);
            }
        }

        //Gets grant total for the report
        public double GrandTotal()
        {
            double totalVal = 0;
            if (itemList.Count > 0)
            {
                foreach (var item in itemList)
                {
                    totalVal += item.TotalValue;
                }
            }

            return totalVal;
        }

        //Updates item for the given data
        public bool UpdateInventory(Inventory item)
        {
            try
            {
                Inventory updateItem = itemList.SingleOrDefault(p => p.Id == 1);
                if (item != null && updateItem != null)
                {
                    itemList.Remove(updateItem);
                    itemList.Add(item);
                }

                return true;
            }
            catch (Exception ex)
            {
                //Implement logger here
                throw new Exception("Update Item Command failed update item." + ex.Message);
            }
        }

      
    }
}
