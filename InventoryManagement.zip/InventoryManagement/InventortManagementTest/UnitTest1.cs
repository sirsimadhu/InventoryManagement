﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace InventortManagementTest
{
    [TestClass]
    public class RepositoryTest
    {
        
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
